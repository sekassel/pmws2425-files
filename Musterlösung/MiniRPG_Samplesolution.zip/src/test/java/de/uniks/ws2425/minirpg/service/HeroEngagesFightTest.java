package de.uniks.ws2425.minirpg.service;

import de.uniks.ws2425.minirpg.model.*;
import de.uniks.ws2425.minirpg.utils.Constants;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class HeroEngagesFightTest {
    private final Hero hero = new Hero()
            .setName("Sir Slayalot")
            .setCurrentLP(100)
            .setCoins(30)
            .setHardMode(false)
            .withStats(
                    new AttackStat()
                            .setLevel(2)
                            .setValue(15)
                            .setCost(5),
                    new DefenseStat()
                            .setLevel(3)
                            .setValue(20)
                            .setCost(5),
                    new HealthStat()
                            .setLevel(1)
                            .setValue(100)
                            .setCost(50)
            );

    private final Enemy troll = new Enemy()
            .setName("Troll")
            .setCurrentLP(40)
            .setMaxLP(40)
            .setAttackValue(15)
            .setDefenseValue(15)
            .setCoins(15);

    private final Enemy skeleton = new Enemy()
            .setName("Skeleton")
            .setCurrentLP(25)
            .setMaxLP(25)
            .setAttackValue(30)
            .setDefenseValue(5)
            .setCoins(25);

    @Test
    public void heroEngagesFightTestBothAttacking() {
        GameService gameService = new GameService();
        gameService.heroEngagesFight(troll.setStance(Constants.ATTACKING), hero, Constants.ATTACKING);

        Assertions.assertEquals(85, hero.getCurrentLP());
        Assertions.assertEquals(25, troll.getCurrentLP());
    }

    @Test
    public void heroEngagesFightTestHeroAttacking() {
        GameService gameService = new GameService();
        gameService.heroEngagesFight(troll.setStance(Constants.DEFENDING), hero, Constants.ATTACKING);

        Assertions.assertEquals(100, hero.getCurrentLP());
        Assertions.assertEquals(40, troll.getCurrentLP());
    }

    @Test
    public void heroEngagesFightTestHeroDefending() {
        GameService gameService = new GameService();
        gameService.heroEngagesFight(skeleton.setStance(Constants.ATTACKING), hero, Constants.DEFENDING);

        Assertions.assertEquals(90, hero.getCurrentLP());
        Assertions.assertEquals(25, skeleton.getCurrentLP());
    }

    @Test
    public void heroEngagesFightTestBothDefending() {
        GameService gameService = new GameService();
        gameService.heroEngagesFight(skeleton.setStance(Constants.DEFENDING), hero, Constants.DEFENDING);

        Assertions.assertEquals(100, hero.getCurrentLP());
        Assertions.assertEquals(25, skeleton.getCurrentLP());
    }
}
