package de.uniks.ws2425.minirpg.service;

import de.uniks.ws2425.minirpg.model.AttackStat;
import de.uniks.ws2425.minirpg.model.DefenseStat;
import de.uniks.ws2425.minirpg.model.Game;
import de.uniks.ws2425.minirpg.model.Hero;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class GameServiceTest {

    @Test
    public void initGameTest() {
        GameService gameService = new GameService();
        Hero hero = new Hero()
                .setName("Sir Slayalot")
                .setCurrentLP(100)
                .setCoins(30)
                .setHardMode(false)
                .withStats(
                        new AttackStat()
                                .setLevel(2)
                                .setValue(15)
                                .setCost(5),
                        new DefenseStat()
                                .setLevel(3)
                                .setValue(20)
                                .setCost(5)
                );

        Game game = gameService.initGame(hero, 1337);

        Assertions.assertEquals(game.getHero(), hero);
        Assertions.assertEquals(game.getHero().getOpponent(), game.getEnemies().getFirst());
        Assertions.assertEquals(6, game.getEnemies().size());
        Assertions.assertEquals("Sir Slayalot", game.getHero().getName());
        Assertions.assertEquals(30, game.getHero().getCoins());

        AttackStat attackStat = game.getHero().getStats().stream().filter(stat -> stat instanceof AttackStat).map(stat -> (AttackStat) stat).findFirst().orElse(null);

        Assertions.assertNotNull(attackStat);
        Assertions.assertEquals(attackStat.getLevel(), 2);
        Assertions.assertEquals(attackStat.getValue(), 15);
        Assertions.assertEquals(attackStat.getCost(), 5);
    }
}
