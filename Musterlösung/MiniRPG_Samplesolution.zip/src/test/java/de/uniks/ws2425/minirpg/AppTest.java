package de.uniks.ws2425.minirpg;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.testfx.framework.junit5.ApplicationTest;

class AppTest extends ApplicationTest {
    private App app;
    private Stage stage;

    @Override
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        app = new App(1337);
        app.start(stage);
    }

    @Test
    void changeViewTest() {
        Assertions.assertEquals("MiniRPG - Setup", stage.getTitle());

        clickOn("#heroNameField").write("Sir Slayalot");
        clickOn("#createAndStartButton");

        Assertions.assertEquals("MiniRPG - InGame", stage.getTitle());

        Label dungeonNameLabel = lookup("#dungeonNameLabel").query();
        Assertions.assertEquals("Gloomspire Cavern", dungeonNameLabel.getText());

        Label maxRoundLabel = lookup("#maxRoundLabel").query();
        Assertions.assertEquals("6", maxRoundLabel.getText());

        Label enemyCurrentLpLabel = lookup("#monsterLpLabel").query();
        Assertions.assertEquals("20 / 20", enemyCurrentLpLabel.getText());

        Label heroCurrentLpLabel = lookup("#heroLpLabel").query();
        Assertions.assertEquals("100 / 100", heroCurrentLpLabel.getText());

        Label heroCoinsLabel = lookup("#heroCoinsLabel").query();
        Assertions.assertEquals("10", heroCoinsLabel.getText());

        Label heroStatLevelLabel = lookup("#heroStatLevelLabel").query();
        Assertions.assertEquals("1", heroStatLevelLabel.getText());

        clickOn("#leaveButton");

        Assertions.assertEquals("MiniRPG - Setup", stage.getTitle());

        TextField heroNameField = lookup("#heroNameField").query();
        Assertions.assertEquals("", heroNameField.getText());
    }
}
