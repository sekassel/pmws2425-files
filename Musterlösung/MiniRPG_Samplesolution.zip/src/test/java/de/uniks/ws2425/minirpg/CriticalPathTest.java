package de.uniks.ws2425.minirpg;

import de.uniks.ws2425.minirpg.model.*;
import de.uniks.ws2425.minirpg.service.PersistenceService;
import de.uniks.ws2425.minirpg.utils.Constants;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.testfx.framework.junit5.ApplicationTest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

class CriticalPathTest extends ApplicationTest {
    private Stage stage;

    @BeforeAll
    public static void before() {
        try {
            Files.deleteIfExists(Path.of(Constants.SAVED_HEROS_FILE));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        App app = new App(4242);
        app.start(stage);
    }

    @Test
    public void testCriticalPath() throws IOException {
        clickOn("#heroNameField").write("Critical Hans");

        clickOn("#createAndStartButton");

        for (int i = 0; i < 17; i++) {
            clickOn("#attackButton");
            clickOn("#defenseButton");
        }

        clickOn("#lvlUpButton");
        clickOn("#lvlUpButton");

        for (int i = 0; i < 4; i++) {
            clickOn("#attackButton");
        }

        Assertions.assertEquals("MiniRPG - Setup", stage.getTitle());

        PersistenceService persistenceService = new PersistenceService();
        List<Hero> heroes = persistenceService.loadHeros();

        Assertions.assertEquals(1, heroes.size());

        Hero hero = heroes.getFirst();

        HeroStat attackStat = hero.getStats().stream().filter(stat -> stat instanceof AttackStat).findFirst().orElse(null);
        HeroStat defenseStat = hero.getStats().stream().filter(stat -> stat instanceof DefenseStat).findFirst().orElse(null);
        HeroStat healthStat = hero.getStats().stream().filter(stat -> stat instanceof HealthStat).findFirst().orElse(null);

        Assertions.assertEquals(3, attackStat.getLevel());
        Assertions.assertEquals(1, defenseStat.getLevel());
        Assertions.assertEquals(1, healthStat.getLevel());

        Label lpLabel = lookup("#lpLabel").query();
        Label atkLevelLabel = lookup("#atkLevelLabel").query();
        Label defLevelLabel = lookup("#defLevelLabel").query();
        Label coinsLabel = lookup("#coinsLabel").query();

        Assertions.assertEquals("100", lpLabel.getText());
        Assertions.assertEquals("3", atkLevelLabel.getText());
        Assertions.assertEquals("1", defLevelLabel.getText());
        Assertions.assertEquals("18", coinsLabel.getText());

        clickOn("#startButton");

        clickOn("#lvlUpButton");
        clickOn("#leaveButton");

        lpLabel = lookup("#lpLabel").query();
        atkLevelLabel = lookup("#atkLevelLabel").query();
        defLevelLabel = lookup("#defLevelLabel").query();
        coinsLabel = lookup("#coinsLabel").query();

        Assertions.assertEquals("100", lpLabel.getText());
        Assertions.assertEquals("3", atkLevelLabel.getText());
        Assertions.assertEquals("1", defLevelLabel.getText());
        Assertions.assertEquals("18", coinsLabel.getText());
    }
}
