package de.uniks.ws2425.minirpg.service;

import de.uniks.ws2425.minirpg.model.Hero;
import de.uniks.ws2425.minirpg.model.HeroStat;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class HeroStatUpdateTest {

    @Test
    public void testHeroStatUpdateSuccess() {
        GameService gameService = new GameService();
        Hero hero = new Hero().setCoins(100);
        HeroStat heroStat = new HeroStat()
                .setHero(hero)
                .setLevel(1)
                .setValue(10)
                .setCost(8)
                .setHero(hero);

        gameService.heroStatUpdate(heroStat);

        Assertions.assertEquals(2, heroStat.getLevel());
        Assertions.assertEquals(13, heroStat.getValue());
        Assertions.assertEquals(10, heroStat.getCost());
        Assertions.assertEquals(92, hero.getCoins());
    }

    @Test
    public void testHeroStatUpdateFail() {
        GameService gameService = new GameService();
        Hero hero = new Hero().setCoins(5);
        HeroStat heroStat = new HeroStat()
                .setHero(hero)
                .setLevel(1)
                .setValue(10)
                .setCost(8)
                .setHero(hero);

        gameService.heroStatUpdate(heroStat);

        Assertions.assertEquals(1, heroStat.getLevel());
        Assertions.assertEquals(10, heroStat.getValue());
        Assertions.assertEquals(8, heroStat.getCost());
        Assertions.assertEquals(5, hero.getCoins());
    }
}
