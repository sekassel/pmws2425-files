package de.uniks.ws2425.minirpg.service;

import de.uniks.ws2425.minirpg.model.Enemy;
import de.uniks.ws2425.minirpg.model.Hero;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class EvaluateFightTest {

    @Test
    public void testEvaluateFightEnemyLives() {
        Hero hero = new Hero();
        Enemy enemy = new Enemy().setCurrentLP(20).setOpponent(hero);

        GameService gameService = new GameService();
        gameService.evaluateFight(enemy, hero);

        Assertions.assertEquals(20, enemy.getCurrentLP());
        Assertions.assertEquals(hero.getOpponent(), enemy);
    }

    @Test
    public void testEvaluateFightEnemyDiesNormalMode() {
        Hero hero = new Hero().setCurrentLP(20).setCoins(42).setHardMode(false);
        Enemy enemy = new Enemy().setCurrentLP(0).setOpponent(hero).setCoins(27);

        GameService gameService = new GameService();
        gameService.evaluateFight(enemy, hero);

        Assertions.assertEquals(100, hero.getCurrentLP());
        Assertions.assertEquals(69, hero.getCoins());
        Assertions.assertNull(hero.getOpponent());
    }

    @Test
    public void testEvaluateFightEnemyDiesHardMode() {
        Hero hero = new Hero().setCurrentLP(55).setCoins(12).setHardMode(true);
        Enemy enemy = new Enemy().setNext(new Enemy()).setCurrentLP(0).setOpponent(hero).setCoins(5);

        GameService gameService = new GameService();
        gameService.evaluateFight(enemy, hero);

        Assertions.assertEquals(17, hero.getCoins());
        Assertions.assertNotNull(hero.getOpponent());
        Assertions.assertEquals(55, hero.getCurrentLP());
    }
}
