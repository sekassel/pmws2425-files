package de.uniks.ws2425.minirpg.service;

import de.uniks.ws2425.minirpg.model.*;
import de.uniks.ws2425.minirpg.utils.Constants;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GameService {
    private final Random random = new Random();

    public GameService() {

    }

    public GameService(int seed) {
        random.setSeed(seed);
    }

    public Game initGame(Hero hero) {
        String dungeonName = Constants.DUNGEON_NAMES.get(random.nextInt(0, Constants.DUNGEON_NAMES.size()));

        Game game = new Game()
                .setHero(hero)
                .setName(dungeonName);

        int enemyCount = random.nextInt(1, 6);

        HeroStat attackStat = hero.getStats().stream().filter(stat -> stat instanceof AttackStat).findFirst().orElse(null);
        HeroStat defenseStat = hero.getStats().stream().filter(stat -> stat instanceof DefenseStat).findFirst().orElse(null);
        HeroStat healthStat = hero.getStats().stream().filter(stat -> stat instanceof HealthStat).findFirst().orElse(null);

        int prevAttackValue = defenseStat != null ? (int) (defenseStat.getValue() * 0.7) : 10;
        int prevDefenseValue = attackStat != null ? (int) (attackStat.getValue() * 0.7) : 10;
        int prevHealthValue = healthStat != null ? (int) (healthStat.getValue() * 0.2) : 20;

        for (int i = 0; i <= enemyCount; i++) {
            Enemy enemy = new Enemy();

            String enemyName = Constants.ENEMY_NAMES.get(random.nextInt(0, Constants.ENEMY_NAMES.size()));
            enemy.setName(enemyName);

            if (i > 0) {
                enemy.setAttackValue(prevAttackValue + random.nextInt(2, 6));
                enemy.setDefenseValue(prevDefenseValue + random.nextInt(2, 5));
                enemy.setMaxLP(prevHealthValue + random.nextInt(10, 20));
                enemy.setCurrentLP(enemy.getMaxLP());
            } else {
                enemy.setAttackValue(prevAttackValue);
                enemy.setDefenseValue(prevDefenseValue);
                enemy.setMaxLP(prevHealthValue);
                enemy.setCurrentLP(enemy.getMaxLP());
            }


            prevAttackValue = enemy.getAttackValue();
            prevDefenseValue = enemy.getDefenseValue();
            prevHealthValue = enemy.getMaxLP();

            enemy.setCoins(random.nextInt(2 * (i + 1), 10 * (i + 1)));


            if (i == 0) {
                enemy.setOpponent(game.getHero());
                enemy.setStance(getRandomStance());
            } else {
                enemy.setPrevious(game.getEnemies().get(i - 1));
            }

            enemy.setGame(game);
        }

        return game;
    }

    public Game initGame(Hero hero, int seed) {
        random.setSeed(seed);
        return initGame(hero);
    }

    public void heroStatUpdate(HeroStat heroStat) {
        if (heroStat.getCost() > heroStat.getHero().getCoins()) {
            return;
        }

        heroStat.getHero().setCoins(heroStat.getHero().getCoins() - heroStat.getCost());

        heroStat.setLevel(heroStat.getLevel() + 1);
        heroStat.setCost((int) Math.round(heroStat.getCost() * Constants.UPGRADE_MODIFIER));

        if (heroStat instanceof HealthStat) {
            int prevValue = heroStat.getValue();
            heroStat.setValue((int) Math.round(heroStat.getValue() * Constants.UPGRADE_HEALTH_MODIFIER));
            heroStat.getHero().setCurrentLP(heroStat.getHero().getCurrentLP() + heroStat.getValue() - prevValue);
            return;
        }

        heroStat.setValue((int) Math.round(heroStat.getValue() * Constants.UPGRADE_MODIFIER));
    }

    public void heroEngagesFight(Enemy enemy, Hero hero, String heroAction) {
        HeroStat attackStat = hero.getStats().stream().filter(stat -> stat instanceof AttackStat).findFirst().orElse(null);
        HeroStat defenseStat = hero.getStats().stream().filter(stat -> stat instanceof DefenseStat).findFirst().orElse(null);

        if (attackStat == null || defenseStat == null) {
            Logger.getLogger(GameService.class.getName()).log(Level.SEVERE, null, "Hero has no attack or defense stat");
            return;
        }

        int damage;

        if (heroAction.equals(Constants.ATTACKING)) {
            if (enemy.getStance().equals(Constants.ATTACKING)) {
                // Both Attacking
                enemy.setCurrentLP(enemy.getCurrentLP() - attackStat.getValue());

                if (enemy.getCurrentLP() > 0) {
                    hero.setCurrentLP(hero.getCurrentLP() - enemy.getAttackValue());
                }

            } else {
                // Hero Attacking, Enemy Defending
                damage = attackStat.getValue() - enemy.getDefenseValue();

                if (damage < 0) {
                    damage = 0;
                }

                enemy.setCurrentLP(enemy.getCurrentLP() - damage);
            }
        } else {
            if (enemy.getStance().equals(Constants.ATTACKING)) {
                // Hero Defending, Enemy Attacking
                damage = enemy.getAttackValue() - defenseStat.getValue();

                if (damage < 0) {
                    damage = 0;
                }

                hero.setCurrentLP(hero.getCurrentLP() - damage);
            }
            // Both Defending, nothing happens
        }

        if (hero.getCurrentLP() < 0) {
            hero.setCurrentLP(0);
        }

        if (enemy.getCurrentLP() < 0) {
            enemy.setCurrentLP(0);
        }
    }

    public void evaluateFight(Enemy enemy, Hero hero) {
        if (enemy.getCurrentLP() > 0) {
            enemy.setStance(getRandomStance());
            return;
        }

        hero.setCoins(hero.getCoins() + enemy.getCoins());

        HeroStat healthStat = hero.getStats().stream().filter(stat -> stat instanceof HealthStat).findFirst().orElse(null);

        if (!hero.isHardMode()) {
            hero.setCurrentLP(healthStat != null ? healthStat.getValue() : 100);
        }

        if (enemy.getNext() == null) {
            hero.setCurrentLP(healthStat != null ? healthStat.getValue() : 100);
            hero.setOpponent(null);
            return;
        }

        hero.setOpponent(enemy.getNext().setStance(getRandomStance()));
    }

    private String getRandomStance() {
        return random.nextInt() % 2 == 0 ? Constants.ATTACKING : Constants.DEFENDING;
    }
}
