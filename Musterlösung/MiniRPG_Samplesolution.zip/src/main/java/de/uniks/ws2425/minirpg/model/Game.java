package de.uniks.ws2425.minirpg.model;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Collections;
import java.util.Collection;
import java.beans.PropertyChangeSupport;

public class Game
{
   public static final String PROPERTY_NAME = "name";
   public static final String PROPERTY_HERO = "hero";
   public static final String PROPERTY_ENEMIES = "enemies";
   private String name;
   private Hero hero;
   private List<Enemy> enemies;
   protected PropertyChangeSupport listeners;

   public String getName()
   {
      return this.name;
   }

   public Game setName(String value)
   {
      if (Objects.equals(value, this.name))
      {
         return this;
      }

      final String oldValue = this.name;
      this.name = value;
      this.firePropertyChange(PROPERTY_NAME, oldValue, value);
      return this;
   }

   public Hero getHero()
   {
      return this.hero;
   }

   public Game setHero(Hero value)
   {
      if (this.hero == value)
      {
         return this;
      }

      final Hero oldValue = this.hero;
      if (this.hero != null)
      {
         this.hero = null;
         oldValue.setGame(null);
      }
      this.hero = value;
      if (value != null)
      {
         value.setGame(this);
      }
      this.firePropertyChange(PROPERTY_HERO, oldValue, value);
      return this;
   }

   public List<Enemy> getEnemies()
   {
      return this.enemies != null ? Collections.unmodifiableList(this.enemies) : Collections.emptyList();
   }

   public Game withEnemies(Enemy value)
   {
      if (this.enemies == null)
      {
         this.enemies = new ArrayList<>();
      }
      if (!this.enemies.contains(value))
      {
         this.enemies.add(value);
         value.setGame(this);
         this.firePropertyChange(PROPERTY_ENEMIES, null, value);
      }
      return this;
   }

   public Game withEnemies(Enemy... value)
   {
      for (final Enemy item : value)
      {
         this.withEnemies(item);
      }
      return this;
   }

   public Game withEnemies(Collection<? extends Enemy> value)
   {
      for (final Enemy item : value)
      {
         this.withEnemies(item);
      }
      return this;
   }

   public Game withoutEnemies(Enemy value)
   {
      if (this.enemies != null && this.enemies.remove(value))
      {
         value.setGame(null);
         this.firePropertyChange(PROPERTY_ENEMIES, value, null);
      }
      return this;
   }

   public Game withoutEnemies(Enemy... value)
   {
      for (final Enemy item : value)
      {
         this.withoutEnemies(item);
      }
      return this;
   }

   public Game withoutEnemies(Collection<? extends Enemy> value)
   {
      for (final Enemy item : value)
      {
         this.withoutEnemies(item);
      }
      return this;
   }

   public boolean firePropertyChange(String propertyName, Object oldValue, Object newValue)
   {
      if (this.listeners != null)
      {
         this.listeners.firePropertyChange(propertyName, oldValue, newValue);
         return true;
      }
      return false;
   }

   public PropertyChangeSupport listeners()
   {
      if (this.listeners == null)
      {
         this.listeners = new PropertyChangeSupport(this);
      }
      return this.listeners;
   }

   @Override
   public String toString()
   {
      final StringBuilder result = new StringBuilder();
      result.append(' ').append(this.getName());
      return result.substring(1);
   }

   public void removeYou()
   {
      this.setHero(null);
      this.withoutEnemies(new ArrayList<>(this.getEnemies()));
   }
}
