package de.uniks.ws2425.minirpg.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import de.uniks.ws2425.minirpg.model.Hero;
import de.uniks.ws2425.minirpg.utils.Constants;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PersistenceService {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private List<Hero> savedHeros = new ArrayList<>();

    public PersistenceService() {
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        objectMapper.activateDefaultTyping(
                objectMapper.getPolymorphicTypeValidator(),
                ObjectMapper.DefaultTyping.NON_FINAL
        );
    }

    public void saveHero(Hero hero) {
        String heroName = hero.getName();

        savedHeros.removeIf(h -> h.getName().equals(heroName));
        savedHeros.add(hero);

        try {
            objectMapper.writeValue(new File(Constants.SAVED_HEROS_FILE), savedHeros);
        } catch (IOException e) {
            Logger.getLogger(PersistenceService.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    public List<Hero> loadHeros() throws IOException {
        List<Hero> heros = new ArrayList<>();

        Path path = Path.of(Constants.SAVED_HEROS_FILE);
        if (Files.notExists(path)) {
            Files.createFile(path);
            return new ArrayList<>();
        }

        try {
            String json = Files.readString(path);

            if (json.isEmpty()) {
                return new ArrayList<>();
            }

            heros = objectMapper.readValue(json.getBytes(StandardCharsets.UTF_8), new TypeReference<List<Hero>>() {});
        } catch (IOException e) {
            Logger.getLogger(PersistenceService.class.getName()).log(Level.SEVERE, null, e);
        }

        savedHeros = heros;
        return heros;
    }
}
