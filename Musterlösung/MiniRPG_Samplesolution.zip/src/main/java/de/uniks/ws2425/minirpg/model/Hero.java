package de.uniks.ws2425.minirpg.model;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Collections;
import java.util.Collection;
import java.beans.PropertyChangeSupport;

public class Hero
{
   public static final String PROPERTY_NAME = "name";
   public static final String PROPERTY_CURRENT_LP = "currentLP";
   public static final String PROPERTY_COINS = "coins";
   public static final String PROPERTY_HARD_MODE = "hardMode";
   public static final String PROPERTY_STATS = "stats";
   public static final String PROPERTY_GAME = "game";
   public static final String PROPERTY_OPPONENT = "opponent";
   private String name;
   private int currentLP;
   private int coins;
   private boolean hardMode;
   @JsonManagedReference
   private List<HeroStat> stats;
   @JsonIgnore
   private Game game;
   @JsonIgnore
   private Enemy opponent;
   protected PropertyChangeSupport listeners;

   public String getName()
   {
      return this.name;
   }

   public Hero setName(String value)
   {
      if (Objects.equals(value, this.name))
      {
         return this;
      }

      final String oldValue = this.name;
      this.name = value;
      this.firePropertyChange(PROPERTY_NAME, oldValue, value);
      return this;
   }

   public int getCurrentLP()
   {
      return this.currentLP;
   }

   public Hero setCurrentLP(int value)
   {
      if (value == this.currentLP)
      {
         return this;
      }

      final int oldValue = this.currentLP;
      this.currentLP = value;
      this.firePropertyChange(PROPERTY_CURRENT_LP, oldValue, value);
      return this;
   }

   public int getCoins()
   {
      return this.coins;
   }

   public Hero setCoins(int value)
   {
      if (value == this.coins)
      {
         return this;
      }

      final int oldValue = this.coins;
      this.coins = value;
      this.firePropertyChange(PROPERTY_COINS, oldValue, value);
      return this;
   }

   public boolean isHardMode()
   {
      return this.hardMode;
   }

   public Hero setHardMode(boolean value)
   {
      if (value == this.hardMode)
      {
         return this;
      }

      final boolean oldValue = this.hardMode;
      this.hardMode = value;
      this.firePropertyChange(PROPERTY_HARD_MODE, oldValue, value);
      return this;
   }

   public List<HeroStat> getStats()
   {
      return this.stats != null ? Collections.unmodifiableList(this.stats) : Collections.emptyList();
   }

   public Hero withStats(HeroStat value)
   {
      if (this.stats == null)
      {
         this.stats = new ArrayList<>();
      }
      if (!this.stats.contains(value))
      {
         this.stats.add(value);
         value.setHero(this);
         this.firePropertyChange(PROPERTY_STATS, null, value);
      }
      return this;
   }

   public Hero withStats(HeroStat... value)
   {
      for (final HeroStat item : value)
      {
         this.withStats(item);
      }
      return this;
   }

   public Hero withStats(Collection<? extends HeroStat> value)
   {
      for (final HeroStat item : value)
      {
         this.withStats(item);
      }
      return this;
   }

   public Hero withoutStats(HeroStat value)
   {
      if (this.stats != null && this.stats.remove(value))
      {
         value.setHero(null);
         this.firePropertyChange(PROPERTY_STATS, value, null);
      }
      return this;
   }

   public Hero withoutStats(HeroStat... value)
   {
      for (final HeroStat item : value)
      {
         this.withoutStats(item);
      }
      return this;
   }

   public Hero withoutStats(Collection<? extends HeroStat> value)
   {
      for (final HeroStat item : value)
      {
         this.withoutStats(item);
      }
      return this;
   }

   public Game getGame()
   {
      return this.game;
   }

   public Hero setGame(Game value)
   {
      if (this.game == value)
      {
         return this;
      }

      final Game oldValue = this.game;
      if (this.game != null)
      {
         this.game = null;
         oldValue.setHero(null);
      }
      this.game = value;
      if (value != null)
      {
         value.setHero(this);
      }
      this.firePropertyChange(PROPERTY_GAME, oldValue, value);
      return this;
   }

   public Enemy getOpponent()
   {
      return this.opponent;
   }

   public Hero setOpponent(Enemy value)
   {
      if (this.opponent == value)
      {
         return this;
      }

      final Enemy oldValue = this.opponent;
      if (this.opponent != null)
      {
         this.opponent = null;
         oldValue.setOpponent(null);
      }
      this.opponent = value;
      if (value != null)
      {
         value.setOpponent(this);
      }
      this.firePropertyChange(PROPERTY_OPPONENT, oldValue, value);
      return this;
   }

   public boolean firePropertyChange(String propertyName, Object oldValue, Object newValue)
   {
      if (this.listeners != null)
      {
         this.listeners.firePropertyChange(propertyName, oldValue, newValue);
         return true;
      }
      return false;
   }

   public PropertyChangeSupport listeners()
   {
      if (this.listeners == null)
      {
         this.listeners = new PropertyChangeSupport(this);
      }
      return this.listeners;
   }

   @Override
   public String toString()
   {
      final StringBuilder result = new StringBuilder();
      result.append(' ').append(this.getName());
      return result.substring(1);
   }

   public void removeYou()
   {
      this.withoutStats(new ArrayList<>(this.getStats()));
      this.setGame(null);
      this.setOpponent(null);
   }
}
