package de.uniks.ws2425.minirpg.utils;

import java.util.List;

public class Constants {
    public static final double UPGRADE_MODIFIER = 1.3;
    public static final double UPGRADE_HEALTH_MODIFIER = 1.15;
    public static final String ATTACKING = "Attacking";
    public static final String DEFENDING = "Defending";
    public static final String SAVED_HEROS_FILE = "data/heros.json";
    public static final List<String> ENEMY_NAMES = List.of("Darksludge", "Frogrik", "Hydra", "Julibun", "Kannnix", "Sebkun", "SlimeKing", "Wingardiumaven");
    public static final List<String> DUNGEON_NAMES = List.of(
            "Abyss of Shadows",
            "Gloomspire Cavern",
            "Crypt of the Forgotten Kings",
            "The Shattered Labyrinth",
            "Frostfang Hollow",
            "Blackthorn Catacombs",
            "Doomspire Vault",
            "Whispering Abyss",
            "The Infernal Depths",
            "Tomb of Eternal Night",
            "Serpent's Maw Cavern",
            "Dreadfire Pit",
            "Ruins of the Lost Citadel",
            "The Obsidian Catacomb",
            "Grimveil Sanctum",
            "The Sunless Grotto",
            "Hollowspire Crypt",
            "Darkwater Dungeon",
            "The Forsaken Halls",
            "Bloodstone Bastion"
    );
}
