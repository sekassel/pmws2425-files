package de.uniks.ws2425.minirpg.model;

public class DefenseStat extends HeroStat
{
}
