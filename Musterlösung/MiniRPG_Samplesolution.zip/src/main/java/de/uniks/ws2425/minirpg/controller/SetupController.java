package de.uniks.ws2425.minirpg.controller;

import de.uniks.ws2425.minirpg.App;
import de.uniks.ws2425.minirpg.Main;
import de.uniks.ws2425.minirpg.controller.subcontroller.SavedHeroViewSubController;
import de.uniks.ws2425.minirpg.model.*;
import de.uniks.ws2425.minirpg.service.PersistenceService;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SetupController implements Controller {
    private final App app;
    private final PersistenceService persistenceService;

    private TextField heroNameField;
    private CheckBox hardModeButton;

    private final List<Controller> subviewController = new ArrayList<>();

    public SetupController(App app) {
        this.app = app;
        this.persistenceService = new PersistenceService();
    }

    public SetupController(App app, PersistenceService persistenceService) {
        this.app = app;
        this.persistenceService = persistenceService;
    }

    @Override
    public String getTitle() {
        return "MiniRPG - Setup";
    }

    @Override
    public void init() {
    }

    @Override
    public Parent render() throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(Main.class.getResource("view/Setup.fxml")));

        heroNameField = (TextField) parent.lookup("#heroNameField");
        hardModeButton = (CheckBox) parent.lookup("#hardModeButton");

        Button createAndStartButton = (Button) parent.lookup("#createAndStartButton");

        createAndStartButton.setOnAction(e -> {
            String heroName = heroNameField.getText();
            boolean hardMode = hardModeButton.isSelected();

            Hero hero = new Hero()
                    .setName(heroName)
                    .setCurrentLP(100)
                    .setCoins(10)
                    .setHardMode(hardMode)
                    .withStats(
                            new AttackStat()
                                    .setLevel(1)
                                    .setValue(7)
                                    .setCost(5),
                            new DefenseStat()
                                    .setLevel(1)
                                    .setValue(5)
                                    .setCost(5),
                            new HealthStat()
                                    .setLevel(1)
                                    .setValue(100)
                                    .setCost(50)
                    );

            persistenceService.saveHero(hero);

            Game game = app.getGameService().initGame(hero);

            app.show(new InGameController(app, game, persistenceService));
        });

        VBox savedHeroBox = (VBox) parent.lookup("#savedHeroBox");

        List<Hero> savedHeros = persistenceService.loadHeros();

        for (Hero savedHero : savedHeros) {
            SavedHeroViewSubController savedHeroViewSubController = new SavedHeroViewSubController(app, savedHero, persistenceService);
            Parent savedHeroView = savedHeroViewSubController.render();
            subviewController.add(savedHeroViewSubController);
            savedHeroBox.getChildren().add(savedHeroView);
        }

        return parent;
    }

    @Override
    public void destroy() {
        subviewController.forEach(Controller::destroy);
    }
}
