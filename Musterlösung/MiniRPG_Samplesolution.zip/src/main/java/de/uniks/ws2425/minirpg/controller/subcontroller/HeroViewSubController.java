package de.uniks.ws2425.minirpg.controller.subcontroller;

import de.uniks.ws2425.minirpg.App;
import de.uniks.ws2425.minirpg.Main;
import de.uniks.ws2425.minirpg.controller.Controller;
import de.uniks.ws2425.minirpg.controller.SetupController;
import de.uniks.ws2425.minirpg.model.Game;
import de.uniks.ws2425.minirpg.model.HealthStat;
import de.uniks.ws2425.minirpg.model.Hero;
import de.uniks.ws2425.minirpg.model.HeroStat;
import de.uniks.ws2425.minirpg.utils.Constants;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.Objects;

public class HeroViewSubController implements Controller {
    private final Game game;
    private final App app;
    private PropertyChangeListener currentLPListener;
    private PropertyChangeListener coinsListener;

    private Rectangle heroLeftLp;
    private Label heroLpLabel;
    private int currentHeroFullLp;

    private DoubleProperty lpLeftPercent;
    private DoubleProperty lpLostPercent;

    public HeroViewSubController(App app, Game game) {
        this.app = app;
        this.game = game;
    }

    @Override
    public String getTitle() {
        return "";
    }

    @Override
    public void init() {

    }

    @Override
    public Parent render() throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(Main.class.getResource("view/subview/HeroView.fxml")));

        Button attackButton = (Button) parent.lookup("#attackButton");
        attackButton.setOnAction(event -> {
            app.getGameService().heroEngagesFight(game.getHero().getOpponent(), game.getHero(), Constants.ATTACKING);
            app.getGameService().evaluateFight(game.getHero().getOpponent(), game.getHero());
        });

        Button defenseButton = (Button) parent.lookup("#defenseButton");
        defenseButton.setOnAction(event -> {
            app.getGameService().heroEngagesFight(game.getHero().getOpponent(), game.getHero(), Constants.DEFENDING);
            app.getGameService().evaluateFight(game.getHero().getOpponent(), game.getHero());
        });

        Label heroNameLabel = (Label) parent.lookup("#heroNameLabel");
        heroNameLabel.setText(game.getHero().getName());

        Label heroCoinsLabel = (Label) parent.lookup("#heroCoinsLabel");
        heroCoinsLabel.setText(String.valueOf(game.getHero().getCoins()));

        heroLpLabel = (Label) parent.lookup("#heroLpLabel");
        heroLeftLp = (Rectangle) parent.lookup("#heroLeftLp");
        Rectangle heroLostLp = (Rectangle) parent.lookup("#heroLostLp");

        // Bind view properties
        lpLeftPercent = new SimpleDoubleProperty(1.0);
        lpLostPercent = new SimpleDoubleProperty(0.0);
        heroLeftLp.widthProperty().bind(lpLeftPercent.multiply(450.0));
        heroLostLp.widthProperty().bind(lpLostPercent.multiply(450.0));

        HeroStat healthStat = game.getHero().getStats().stream().filter(stat -> stat instanceof HealthStat).findFirst().orElse(null);
        currentHeroFullLp = healthStat != null ? healthStat.getValue() : 100;
        setHeroLpLabel(game.getHero().getCurrentLP());

        currentLPListener = evt -> {
            if (game.getHero().getCurrentLP() <= 0) {
                app.show(new SetupController(app));
            }

            HeroStat innerHealthStat = game.getHero().getStats().stream().filter(stat -> stat instanceof HealthStat).findFirst().orElse(null);
            currentHeroFullLp = innerHealthStat != null ? innerHealthStat.getValue() : 100;
            setHeroLpLabel(game.getHero().getCurrentLP());
        };
        coinsListener = evt -> heroCoinsLabel.setText(String.valueOf(game.getHero().getCoins()));

        game.getHero().listeners().addPropertyChangeListener(Hero.PROPERTY_CURRENT_LP, currentLPListener);
        game.getHero().listeners().addPropertyChangeListener(Hero.PROPERTY_COINS, coinsListener);

        return parent;
    }

    @Override
    public void destroy() {
        game.getHero().listeners().removePropertyChangeListener(Hero.PROPERTY_CURRENT_LP, currentLPListener);
        game.getHero().listeners().removePropertyChangeListener(Hero.PROPERTY_COINS, coinsListener);
    }

    private void setHeroLpLabel(int heroLp) {
        heroLpLabel.setText(heroLp + " / " + currentHeroFullLp);
        lpLeftPercent.setValue(1.0 / currentHeroFullLp * heroLp);
        lpLostPercent.setValue(1.0 - lpLeftPercent.getValue());
        if (heroLp < (currentHeroFullLp * 0.25)) {
            heroLeftLp.setFill(Color.RED);
        } else if (heroLp < (currentHeroFullLp * 0.75)) {
            heroLeftLp.setFill(Color.ORANGE);
        } else {
            heroLeftLp.setFill(Color.GREEN);
        }
    }
}
