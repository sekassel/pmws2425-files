package de.uniks.ws2425.minirpg.service;

import de.uniks.ws2425.minirpg.utils.Constants;
import javafx.scene.image.Image;

import java.util.Objects;

public class ResourceService {

    public static Image loadEnemyAvatar(String enemyName) {
        if (!Constants.ENEMY_NAMES.contains(enemyName)) {
            return new Image(Objects.requireNonNull(ResourceService.class.getResource("../icons/question.png")).toString());
        }

        return new Image(Objects.requireNonNull(ResourceService.class.getResource("../enemies/" + enemyName + ".png")).toString());
    }

    public static Image loadStanceImage(String stance) {
        if (!stance.equals(Constants.ATTACKING) && !stance.equals(Constants.DEFENDING)) {
            return new Image(Objects.requireNonNull(ResourceService.class.getResource("../icons/question.png")).toString());
        }

        return new Image(Objects.requireNonNull(ResourceService.class.getResource("../icons/" + stance + ".png")).toString());
    }

    public static Image loadHeroStatImage(String heroStatName) {
        return switch (heroStatName) {
            case "AttackStat" ->
                    new Image(Objects.requireNonNull(ResourceService.class.getResource("../icons/Attacking.png")).toString());
            case "DefenseStat" ->
                    new Image(Objects.requireNonNull(ResourceService.class.getResource("../icons/Defending.png")).toString());
            case "HealthStat" ->
                    new Image(Objects.requireNonNull(ResourceService.class.getResource("../icons/Health.png")).toString());
            default ->
                    new Image(Objects.requireNonNull(ResourceService.class.getResource("../icons/question.png")).toString());
        };
    }
}
