package de.uniks.ws2425.minirpg.model;
import java.util.Objects;
import java.beans.PropertyChangeSupport;

public class Enemy
{
   public static final String PROPERTY_NAME = "name";
   public static final String PROPERTY_CURRENT_LP = "currentLP";
   public static final String PROPERTY_MAX_LP = "maxLP";
   public static final String PROPERTY_COINS = "coins";
   public static final String PROPERTY_ATTACK_VALUE = "attackValue";
   public static final String PROPERTY_DEFENSE_VALUE = "defenseValue";
   public static final String PROPERTY_STANCE = "stance";
   public static final String PROPERTY_OPPONENT = "opponent";
   public static final String PROPERTY_GAME = "game";
   public static final String PROPERTY_NEXT = "next";
   public static final String PROPERTY_PREVIOUS = "previous";
   private String name;
   private int currentLP;
   private int maxLP;
   private int coins;
   private int attackValue;
   private int defenseValue;
   private String stance;
   private Hero opponent;
   private Game game;
   private Enemy next;
   private Enemy previous;
   protected PropertyChangeSupport listeners;

   public String getName()
   {
      return this.name;
   }

   public Enemy setName(String value)
   {
      if (Objects.equals(value, this.name))
      {
         return this;
      }

      final String oldValue = this.name;
      this.name = value;
      this.firePropertyChange(PROPERTY_NAME, oldValue, value);
      return this;
   }

   public int getCurrentLP()
   {
      return this.currentLP;
   }

   public Enemy setCurrentLP(int value)
   {
      if (value == this.currentLP)
      {
         return this;
      }

      final int oldValue = this.currentLP;
      this.currentLP = value;
      this.firePropertyChange(PROPERTY_CURRENT_LP, oldValue, value);
      return this;
   }

   public int getMaxLP()
   {
      return this.maxLP;
   }

   public Enemy setMaxLP(int value)
   {
      if (value == this.maxLP)
      {
         return this;
      }

      final int oldValue = this.maxLP;
      this.maxLP = value;
      this.firePropertyChange(PROPERTY_MAX_LP, oldValue, value);
      return this;
   }

   public int getCoins()
   {
      return this.coins;
   }

   public Enemy setCoins(int value)
   {
      if (value == this.coins)
      {
         return this;
      }

      final int oldValue = this.coins;
      this.coins = value;
      this.firePropertyChange(PROPERTY_COINS, oldValue, value);
      return this;
   }

   public int getAttackValue()
   {
      return this.attackValue;
   }

   public Enemy setAttackValue(int value)
   {
      if (value == this.attackValue)
      {
         return this;
      }

      final int oldValue = this.attackValue;
      this.attackValue = value;
      this.firePropertyChange(PROPERTY_ATTACK_VALUE, oldValue, value);
      return this;
   }

   public int getDefenseValue()
   {
      return this.defenseValue;
   }

   public Enemy setDefenseValue(int value)
   {
      if (value == this.defenseValue)
      {
         return this;
      }

      final int oldValue = this.defenseValue;
      this.defenseValue = value;
      this.firePropertyChange(PROPERTY_DEFENSE_VALUE, oldValue, value);
      return this;
   }

   public String getStance()
   {
      return this.stance;
   }

   public Enemy setStance(String value)
   {
      if (Objects.equals(value, this.stance))
      {
         return this;
      }

      final String oldValue = this.stance;
      this.stance = value;
      this.firePropertyChange(PROPERTY_STANCE, oldValue, value);
      return this;
   }

   public Hero getOpponent()
   {
      return this.opponent;
   }

   public Enemy setOpponent(Hero value)
   {
      if (this.opponent == value)
      {
         return this;
      }

      final Hero oldValue = this.opponent;
      if (this.opponent != null)
      {
         this.opponent = null;
         oldValue.setOpponent(null);
      }
      this.opponent = value;
      if (value != null)
      {
         value.setOpponent(this);
      }
      this.firePropertyChange(PROPERTY_OPPONENT, oldValue, value);
      return this;
   }

   public Game getGame()
   {
      return this.game;
   }

   public Enemy setGame(Game value)
   {
      if (this.game == value)
      {
         return this;
      }

      final Game oldValue = this.game;
      if (this.game != null)
      {
         this.game = null;
         oldValue.withoutEnemies(this);
      }
      this.game = value;
      if (value != null)
      {
         value.withEnemies(this);
      }
      this.firePropertyChange(PROPERTY_GAME, oldValue, value);
      return this;
   }

   public Enemy getNext()
   {
      return this.next;
   }

   public Enemy setNext(Enemy value)
   {
      if (this.next == value)
      {
         return this;
      }

      final Enemy oldValue = this.next;
      if (this.next != null)
      {
         this.next = null;
         oldValue.setPrevious(null);
      }
      this.next = value;
      if (value != null)
      {
         value.setPrevious(this);
      }
      this.firePropertyChange(PROPERTY_NEXT, oldValue, value);
      return this;
   }

   public Enemy getPrevious()
   {
      return this.previous;
   }

   public Enemy setPrevious(Enemy value)
   {
      if (this.previous == value)
      {
         return this;
      }

      final Enemy oldValue = this.previous;
      if (this.previous != null)
      {
         this.previous = null;
         oldValue.setNext(null);
      }
      this.previous = value;
      if (value != null)
      {
         value.setNext(this);
      }
      this.firePropertyChange(PROPERTY_PREVIOUS, oldValue, value);
      return this;
   }

   public boolean firePropertyChange(String propertyName, Object oldValue, Object newValue)
   {
      if (this.listeners != null)
      {
         this.listeners.firePropertyChange(propertyName, oldValue, newValue);
         return true;
      }
      return false;
   }

   public PropertyChangeSupport listeners()
   {
      if (this.listeners == null)
      {
         this.listeners = new PropertyChangeSupport(this);
      }
      return this.listeners;
   }

   @Override
   public String toString()
   {
      final StringBuilder result = new StringBuilder();
      result.append(' ').append(this.getName());
      result.append(' ').append(this.getStance());
      return result.substring(1);
   }

   public void removeYou()
   {
      this.setOpponent(null);
      this.setGame(null);
      this.setNext(null);
      this.setPrevious(null);
   }
}
