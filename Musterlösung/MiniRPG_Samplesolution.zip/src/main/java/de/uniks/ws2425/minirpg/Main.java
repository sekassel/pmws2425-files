package de.uniks.ws2425.minirpg;

import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(App.class, args);
    }
}
