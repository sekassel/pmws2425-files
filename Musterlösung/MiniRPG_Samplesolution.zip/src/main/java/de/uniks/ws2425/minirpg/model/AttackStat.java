package de.uniks.ws2425.minirpg.model;

public class AttackStat extends HeroStat
{
}
