package de.uniks.ws2425.minirpg.model;

public class HealthStat extends HeroStat
{
}
