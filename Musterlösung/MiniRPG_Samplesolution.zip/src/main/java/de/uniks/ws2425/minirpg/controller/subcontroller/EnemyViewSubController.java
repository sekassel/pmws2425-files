package de.uniks.ws2425.minirpg.controller.subcontroller;

import de.uniks.ws2425.minirpg.App;
import de.uniks.ws2425.minirpg.Main;
import de.uniks.ws2425.minirpg.controller.Controller;
import de.uniks.ws2425.minirpg.controller.SetupController;
import de.uniks.ws2425.minirpg.model.Enemy;
import de.uniks.ws2425.minirpg.model.Game;
import de.uniks.ws2425.minirpg.model.Hero;
import de.uniks.ws2425.minirpg.service.PersistenceService;
import de.uniks.ws2425.minirpg.service.ResourceService;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.Objects;

public class EnemyViewSubController implements Controller {
    private final App app;
    private final Game game;
    private final PersistenceService persistenceService;

    private PropertyChangeListener currentLPListener;
    private PropertyChangeListener stanceListener;

    private Enemy currentEnemy;

    private Label monsterLpLabel;
    private Label monsterNameLabel;
    private ImageView enemyAvatarImageView;
    private ImageView enemyStanceImageView;

    private Rectangle monsterLeftLp;
    private DoubleProperty lpLeftPercent;
    private DoubleProperty lpLostPercent;

    public EnemyViewSubController(App app, Game game, PersistenceService persistenceService) {
        this.app = app;
        this.game = game;
        this.persistenceService = persistenceService;
    }

    @Override
    public String getTitle() {
        return "";
    }

    @Override
    public void init() {

    }

    @Override
    public Parent render() throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(Main.class.getResource("view/subview/EnemyView.fxml")));

        currentEnemy = game.getHero().getOpponent();

        monsterLpLabel = (Label) parent.lookup("#monsterLpLabel");
        monsterNameLabel = (Label) parent.lookup("#monsterNameLabel");
        enemyAvatarImageView = (ImageView) parent.lookup("#enemyAvatarImageView");
        enemyAvatarImageView.setFitHeight(250);
        enemyAvatarImageView.setFitWidth(250);

        enemyStanceImageView = (ImageView) parent.lookup("#enemyStanceImageView");
        enemyStanceImageView.setFitHeight(50);
        enemyStanceImageView.setFitWidth(50);

        monsterLeftLp = (Rectangle) parent.lookup("#monsterLeftLp");
        Rectangle monsterLostLp = (Rectangle) parent.lookup("#monsterLostLp");

        // Bind view properties
        lpLeftPercent = new SimpleDoubleProperty(1.0);
        lpLostPercent = new SimpleDoubleProperty(0.0);
        monsterLeftLp.widthProperty().bind(lpLeftPercent.multiply(450.0));
        monsterLostLp.widthProperty().bind(lpLostPercent.multiply(450.0));

        setMonsterLpLabel(currentEnemy.getCurrentLP());

        currentLPListener = evt -> setMonsterLpLabel(currentEnemy.getCurrentLP());
        stanceListener = evt -> enemyStanceImageView.setImage(ResourceService.loadStanceImage(currentEnemy.getStance()));

        updateView();

        game.getHero().listeners().addPropertyChangeListener(Hero.PROPERTY_OPPONENT, evt -> {
            currentEnemy.listeners().removePropertyChangeListener(Enemy.PROPERTY_CURRENT_LP, currentLPListener);
            currentEnemy.listeners().removePropertyChangeListener(Enemy.PROPERTY_STANCE, stanceListener);

            currentEnemy = game.getHero().getOpponent();

            if (currentEnemy == null) {
                persistenceService.saveHero(game.getHero());

                app.show(new SetupController(app, persistenceService));

                return;
            }

            updateView();
        });

        return parent;
    }

    private void updateView() {
        setMonsterLpLabel(currentEnemy.getCurrentLP());

        monsterNameLabel.setText(String.valueOf(currentEnemy.getName()));

        enemyAvatarImageView.setImage(ResourceService.loadEnemyAvatar(currentEnemy.getName()));

        enemyStanceImageView.setImage(ResourceService.loadStanceImage(currentEnemy.getStance()));

        currentEnemy.listeners().addPropertyChangeListener(Enemy.PROPERTY_CURRENT_LP, currentLPListener);
        currentEnemy.listeners().addPropertyChangeListener(Enemy.PROPERTY_STANCE, stanceListener);
    }

    @Override
    public void destroy() {
        if (currentEnemy == null) {
            return;
        }

        currentEnemy.listeners().removePropertyChangeListener(Enemy.PROPERTY_CURRENT_LP, currentLPListener);
        currentEnemy.listeners().removePropertyChangeListener(Enemy.PROPERTY_STANCE, stanceListener);
    }

    private void setMonsterLpLabel(int monsterLp) {
        monsterLpLabel.setText(monsterLp + " / " + currentEnemy.getMaxLP());
        lpLeftPercent.setValue(1.0 / currentEnemy.getMaxLP() * monsterLp);
        lpLostPercent.setValue(1.0 - lpLeftPercent.getValue());
        if (monsterLp < (currentEnemy.getMaxLP() * 0.25)) {
            monsterLeftLp.setFill(Color.RED);
        } else if (monsterLp < (currentEnemy.getMaxLP() * 0.75)) {
            monsterLeftLp.setFill(Color.ORANGE);
        } else {
            monsterLeftLp.setFill(Color.GREEN);
        }
    }
}
