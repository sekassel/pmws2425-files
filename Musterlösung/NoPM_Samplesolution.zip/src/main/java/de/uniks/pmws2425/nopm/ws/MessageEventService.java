package de.uniks.pmws2425.nopm.ws;

import de.uniks.pmws2425.nopm.model.dto.MessageDto;
import kong.unirest.core.json.JSONObject;

import java.util.function.Consumer;

public class MessageEventService {
    private final ClientEndpoint clientEndpoint;

    public MessageEventService(ClientEndpoint clientEndpoint) {
        this.clientEndpoint = clientEndpoint;
    }

    public Runnable subscribeTopic(String topic, Consumer<MessageDto> callback) {
        clientEndpoint.connect();
        return clientEndpoint.subscribe("topics." + topic + ".messages", message -> {
            callback.accept(fromJson((JSONObject) message));
        });
    }

    private MessageDto fromJson(JSONObject json) {
        return new MessageDto(
                json.getString("topic"),
                json.getString("timestamp"),
                json.getString("sender"),
                json.getString("body"));
    }
}
