package de.uniks.pmws2425.nopm.service;

import de.uniks.pmws2425.nopm.model.Topic;
import de.uniks.pmws2425.nopm.model.dto.CreateMessageDto;
import de.uniks.pmws2425.nopm.model.dto.LoginDto;
import de.uniks.pmws2425.nopm.model.dto.MessageDto;
import kong.unirest.core.*;
import kong.unirest.core.json.JSONArray;
import kong.unirest.core.json.JSONObject;
import kong.unirest.jackson.JacksonObjectMapper;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static de.uniks.pmws2425.nopm.util.Constants.*;
import static kong.unirest.core.Unirest.get;
import static kong.unirest.core.Unirest.post;

public class ChatApiService {

    static {
        Unirest.config().addDefaultHeader("Content-Type", "application/json");
        Unirest.config().setObjectMapper(new JacksonObjectMapper());
    }

    public LoginDto login(LoginDto dto) {
        HttpRequest<?> req = post(API_URL + LOGIN_PATH).body(dto.toJson());
        HttpResponse<JsonNode> res = req.asJson();

        return new LoginDto(res.getBody().getObject().getString("nickname"));
    }

    public void logout(LoginDto dto) {
        post(API_URL + LOGOUT_PATH)
                .body(dto.toJson())
                .asEmpty();
    }

    public List<Topic> getTopics() {
        HttpRequest<GetRequest> req = get(API_URL + TOPIC_PATH);
        HttpResponse<JsonNode> res = req.asJson();

        JSONArray array = res.getBody().getArray();
        ArrayList<Topic> topics = new ArrayList<>();

        for (Object o : array) {
            JSONObject json = (JSONObject) o;
            topics.add(new Topic().setTitle(json.getString("title")));
        }

        return topics;
    }

    public void sendMessage(String topic, CreateMessageDto dto) {
        HttpRequest<?> req = post(API_URL + TOPIC_PATH + "/" + topic + MESSAGE_PATH).body(dto.toJson());
        HttpResponse<JsonNode> res = req.asJson();
        res.getBody().getObject();
    }

    public List<MessageDto> getMessages(String topic, Instant after) {
        HttpRequest<GetRequest> req = get(API_URL + TOPIC_PATH + "/" + topic + MESSAGE_PATH);
        if (Objects.nonNull(after)) {
            req.queryString("after", after.toString());
        }
        HttpResponse<JsonNode> res = req.asJson();

        JSONArray array = res.getBody().getArray();
        ArrayList<MessageDto> messages = new ArrayList<>();

        for (Object o : array) {
            JSONObject json = (JSONObject) o;

            messages.add(fromJson(json));
        }
        return messages;
    }

    private MessageDto fromJson(JSONObject json) {
        return new MessageDto(
                json.getString("topic"),
                json.getString("timestamp"),
                json.getString("sender"),
                json.getString("body"));
    }
}
