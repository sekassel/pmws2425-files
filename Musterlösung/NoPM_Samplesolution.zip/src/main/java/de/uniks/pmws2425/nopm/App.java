package de.uniks.pmws2425.nopm;

import de.uniks.pmws2425.nopm.controller.Controller;
import de.uniks.pmws2425.nopm.controller.LoginController;
import de.uniks.pmws2425.nopm.service.ChatApiService;
import de.uniks.pmws2425.nopm.service.ChatService;
import de.uniks.pmws2425.nopm.ws.ClientEndpoint;
import de.uniks.pmws2425.nopm.ws.MessageEventService;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import kong.unirest.core.Unirest;

import java.util.Objects;

import static de.uniks.pmws2425.nopm.util.Constants.WEBSOCKET_URL;

public class App extends Application {
    private Stage stage;
    private Controller controller;
    private ChatService chatService;
    private ChatApiService chatApiService;
    private ClientEndpoint endpoint;
    private MessageEventService messageEventService;

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.stage = primaryStage;
        primaryStage.setScene(new Scene(new Label("Loading...")));
        primaryStage.setTitle("NoPM");

        chatApiService = new ChatApiService();
        if (Objects.isNull(endpoint)) {
            endpoint = new ClientEndpoint(WEBSOCKET_URL);
        }
        messageEventService = new MessageEventService(endpoint);
        chatService = new ChatService(chatApiService, messageEventService);

        show(new LoginController(this));

        primaryStage.show();

        primaryStage.setOnCloseRequest(e -> controller.destroy());
    }

    @Override
    public void stop() {
        if (controller != null) {
            controller.destroy();
            controller = null;
        }

        this.chatService.logout();
        Unirest.shutDown();
    }

    public void show(Controller controller) {
        controller.init();

        stage.getScene().setRoot(controller.render());
        stage.sizeToScene();

        if (this.controller != null) {
            this.controller.destroy();
        }
        this.controller = controller;
        stage.setTitle(controller.getTitle());
    }

    public ChatService getChatService() {
        return chatService;
    }

    public void seedWebSocket(ClientEndpoint clientEndpoint) {
        this.endpoint = clientEndpoint;
    }
}
