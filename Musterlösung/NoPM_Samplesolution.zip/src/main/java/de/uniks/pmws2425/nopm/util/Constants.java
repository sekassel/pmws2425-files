package de.uniks.pmws2425.nopm.util;

public class Constants {
    public static final String API_URL = "https://nopm.uniks.de/api/v1";
    public static final String WEBSOCKET_URL = "wss://nopm.uniks.de/ws/v1";

    public static final String LOGIN_PATH = "/auth/login";
    public static final String LOGOUT_PATH = "/auth/logout";
    public static final String TOPIC_PATH = "/topics";
    public static final String MESSAGE_PATH = "/messages";
}
