package de.uniks.pmws2425.nopm.model.dto;

import kong.unirest.core.json.JSONObject;

public record MessageDto(
        String topic,
        String timestamp,
        String sender,
        String body
) {
    public JSONObject toJson() {
        return new JSONObject()
                .put("topic", topic)
                .put("timestamp", timestamp)
                .put("sender", sender)
                .put("body", body);
    }
}
