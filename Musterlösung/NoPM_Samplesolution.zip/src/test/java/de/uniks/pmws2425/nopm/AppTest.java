package de.uniks.pmws2425.nopm;

import de.uniks.pmws2425.nopm.model.dto.LoginDto;
import de.uniks.pmws2425.nopm.model.dto.MessageDto;
import de.uniks.pmws2425.nopm.ws.ClientEndpoint;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import kong.unirest.core.HttpMethod;
import kong.unirest.core.MockClient;
import kong.unirest.core.json.JSONArray;
import kong.unirest.core.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.testfx.framework.junit5.ApplicationTest;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static de.uniks.pmws2425.nopm.util.Constants.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

record WsMessageDto(
        String event,
        MessageDto data
) {
    public String toJson() {
        return new JSONObject()
                .put("event", event)
                .put("data", data.toJson())
                .toString();
    }
}

class AppTest extends ApplicationTest {
    public static final String LOCALHOST = "wss://localhost";
    public static final List<String> TOPICS = Arrays.asList("Homework", "Gaming", "Thesis");
    public static final String USERNAME = "Guido van Rossum";
    public static final String MESSAGE = "Now this i'd like to call a party.";

    public static final String OWN_MESSAGE_DTO = new WsMessageDto(
            "topics." + TOPICS.getFirst() + ".messages",
            new MessageDto(
                    USERNAME,
                    Instant.now().toString(),
                    TOPICS.getFirst(),
                    MESSAGE
            )
    ).toJson();

    private Stage stage;
    private MockClient mock;
    private final ClientEndpoint clientEndpoint = spy(new ClientEndpoint(LOCALHOST));

    @Override
    public void start(Stage stage) throws Exception {
        setupMock();
        this.stage = stage;
        App app = new App();
        app.seedWebSocket(clientEndpoint);
        app.start(stage);
    }

    private void setupMock() {
        mock = MockClient.register();
        doNothing().when(clientEndpoint).connect();
        doCallRealMethod().when(clientEndpoint).onMessage(anyString());
    }

    @Test
    void viewChangeTest() {
        mockPostLogin(mock);
        mockPostLogout(mock);
        mockGetTopics(mock);
        mockGetMessages(mock);
        mockPostMessage(mock);

        Assertions.assertEquals("NoPM - Login", stage.getTitle());

        clickOn("#nicknameField").write(USERNAME);
        clickOn("#loginButton");

        Assertions.assertEquals("NoPM - Chat", stage.getTitle());

        Assertions.assertFalse(lookup("#chatTabPane").queryAs(TabPane.class).getTabs().isEmpty());

        List<Tab> tabs = lookup("#chatTabPane").queryAs(javafx.scene.control.TabPane.class).getTabs();

        Tab homeworkTab = tabs.stream().filter(tab -> tab.getText().equals("Homework")).findFirst().orElse(null);

        Assertions.assertNotNull(homeworkTab);

        VBox messageBox = (VBox) homeworkTab.getContent().lookup("#messageBox");

        Assertions.assertEquals(1, messageBox.getChildren().size());

        clickOn("#messageField").write(MESSAGE);
        clickOn("#sendButton");
        clientEndpoint.onMessage(OWN_MESSAGE_DTO);

        Assertions.assertEquals("", lookup("#messageField").queryAs(javafx.scene.control.TextField.class).getText());

        clickOn("#messageField").write("Splendid.");

        Assertions.assertEquals(2, messageBox.getChildren().size());

        clickOn("#logoutButton");

        Assertions.assertEquals("NoPM - Login", stage.getTitle());

    }

    // ========================================================================================================
    // Mock Routes
    // ========================================================================================================

    private void mockPostMessage(MockClient mock) {
        for (String topic : TOPICS) {
            JSONObject json = new JSONObject()
                    .put("sender", USERNAME)
                    .put("topic", topic)
                    .put("body", MESSAGE)
                    .put("timestamp", Instant.now().toString());

            mock.expect(HttpMethod.POST, API_URL + TOPIC_PATH + "/" + topic + MESSAGE_PATH)
                    .thenReturn(json.toString());
        }
    }

    private void mockGetMessages(MockClient mock) {
        for (String topic : TOPICS) {
            List<JSONObject> messages = new ArrayList<>();
            messages.add(new JSONObject()
                    .put("sender", "General Kenobi")
                    .put("topic", topic)
                    .put("body", "Hello there...")
                    .put("timestamp", Instant.now().toString()));

            JSONArray array = new JSONArray(messages);


            mock.expect(HttpMethod.GET, API_URL + TOPIC_PATH + "/" + topic + MESSAGE_PATH)
                    .thenReturn(array.toString());
        }
    }

    private void mockPostLogout(MockClient mock) {
        mock.expect(HttpMethod.POST, API_URL + LOGOUT_PATH).thenReturn();
    }

    private void mockGetTopics(MockClient mock) {
        List<JSONObject> topics = new ArrayList<>();
        TOPICS.forEach(title -> topics.add(new JSONObject().put("title", title)));
        JSONArray array = new JSONArray(topics);

        mock.expect(HttpMethod.GET, API_URL + TOPIC_PATH)
                .thenReturn(array.toString());
    }

    private void mockPostLogin(MockClient mock) {
        String testLoginDto = new LoginDto(USERNAME).toJson();

        mock.expect(HttpMethod.POST, API_URL + LOGIN_PATH)
                .thenReturn(testLoginDto);
    }
}
